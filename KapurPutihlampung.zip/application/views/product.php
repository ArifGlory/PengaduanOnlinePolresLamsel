<div id="colorlib-main">
    <div class="colorlib-work">
        <div class="colorlib-narrow-content">
            <div class="row">
                <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                    <span class="heading-meta">Product</span>
                    <h2 class="colorlib-heading">Our Product</h2>
                </div>
            </div>
            <div class="row row-bottom-padded-md">
                <div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
                    <div class="project" style="background-image: url(<?php echo base_url();?>/foto/batukapur.jpg);">
                        <div class="desc">
                            <div class="con">
                                <h3><a href="work.html">LimeStone</a></h3>
                                <span></span>
                                <p class="icon">

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 animate-box" data-animate-effect="fadeInLeft">
                    <div class="project" style="background-image: url(<?php echo base_url();?>/foto/kapurbakar.jpg);">
                        <div class="desc">
                            <div class="con">
                                <h3><a href="work.html">Quick Lime</a></h3>
                                <span></span>
                                <p class="icon">

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 animate-box" data-animate-effect="fadeInLeft">
                    <div class="project" style="background-image: url(<?php echo base_url();?>/foto/kaptan.jpg);">
                        <div class="desc">
                            <div class="con">
                                <h3><a href="work.html">Agricultural Lime</a></h3>
                                <span></span>
                                <p class="icon">
                                   
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>