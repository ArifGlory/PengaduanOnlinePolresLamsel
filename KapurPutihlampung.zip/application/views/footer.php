<div id="get-in-touch" class="colorlib-bg-color">
    <div class="colorlib-narrow-content">
        <div class="row">
            <div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
                <h2>Get in Touch!</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                <p class="colorlib-lead">Want to know Us more ?</p>
                <p><a href="#" class="btn btn-primary btn-learn">Contact us!</a></p>
            </div>

        </div>
    </div>
</div>
</div>
</div>

<!-- jQuery -->
<script src="<?php echo base_url();?>/assets2/js/jquery.min.js"></script>
<!-- jQuery Easing -->
<script src="<?php echo base_url();?>/assets2/js/jquery.easing.1.3.js"></script>
<!-- Bootstrap -->
<script src="<?php echo base_url();?>/assets2/js/bootstrap.min.js"></script>
<!-- Waypoints -->
<script src="<?php echo base_url();?>/assets2/js/jquery.waypoints.min.js"></script>
<!-- Flexslider -->
<script src="<?php echo base_url();?>/assets2/js/jquery.flexslider-min.js"></script>
<!-- Sticky Kit -->
<script src="<?php echo base_url();?>/assets2/js/sticky-kit.min.js"></script>
<!-- Owl carousel -->
<script src="<?php echo base_url();?>/assets2/js/owl.carousel.min.js"></script>
<!-- Counters -->
<script src="<?php echo base_url();?>/assets2/js/jquery.countTo.js"></script>


<!-- MAIN JS -->
<script src="<?php echo base_url();?>/assets2/js/main.js"></script>

</body>
</html>

